module mux41 (
    input d0, d1, d2, d3,  // Dados de entrada
    input s0, s1,          // Entradas de seleção
    output reg y           // Saída (reg para usar dentro do always)
);

    always @(*) begin
        case ({s1, s0})    // Agrupa as duas chaves de seleção
            2'b00: y = d0; // Se S1=0 e S0=0, escolhe D0
            2'b01: y = d1; // Se S1=0 e S0=1, escolhe D1
            2'b10: y = d2; // Se S1=1 e S0=0, escolhe D2
            2'b11: y = d3; // Se S1=1 e S0=1, escolhe D3
            default: y = 1'bx;
        endcase
    end

endmodule
