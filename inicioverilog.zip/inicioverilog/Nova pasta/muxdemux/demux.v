module demux(
    input S0, S1,
    input D,                     // D é a entrada de dados comum
    output reg Y0, Y1, Y2, Y3    // Todas as saídas viram reg porque mudam no always
);

    always @(*) begin
        // Passo importante: Definir um valor padrão (desligado) para todas as saídas.
        // O case vai mudar apenas a saída que for selecionada!
        Y0 = 0;
        Y1 = 0;
        Y2 = 0;
        Y3 = 0;

        case({S1, S0}) // Mantendo a ordem padrão S1 (mais significativo) e S0
            2'b00: Y0 = D; // Se S=00, Y0 recebe o dado D, as outras continuam 0
            2'b01: Y1 = D; // Se S=01, Y1 recebe o dado D, as outras continuam 0
            2'b10: Y2 = D; // Se S=10, Y2 recebe o dado D, as outras continuam 0
            2'b11: Y3 = D; // Se S=11, Y3 recebe o dado D, as outras continuam 0
            default: begin
                Y0 = 1'bx; Y1 = 1'bx; Y2 = 1'bx; Y3 = 1'bx;
            end
        endcase
    end

endmodule
