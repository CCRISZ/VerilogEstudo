module norr(
    input wire A, B,
    output wire S

);

    assign S = ~(A | B);

endmodule