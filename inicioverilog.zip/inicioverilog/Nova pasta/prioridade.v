module Priori(
    input wire TV, PC, ALE,
    output wire S_TV, S_PC, S_ALE
);

    assign S_ALE = ALE & ~PC & ~TV;
    assign S_PC = PC & ALE & ~TV | PC & ~TV;
    assign S_TV = TV & ALE| TV & PC | TV & PC & ALE| TV;


endmodule

/*

TV PC ALE | S_tV S_PC S_ALE
0  0   1     0     0     1
0  1   0     0     1     0
0  1   1     0     1     0
1  0   0     1     0     0
1  0   1     1     0     0
1  1   0     1     0     0
1  1   1     1     0     0 