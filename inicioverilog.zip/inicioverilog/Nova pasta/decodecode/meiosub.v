module half_subtractor (
    input A, B,
    output S, C
);

    // S = A ⊕ B (Operador XOR)
    assign S = A ^ B; 
    
    // C = ~A · B (Inverte o A e faz um AND com B)
    // Só pede emprestado se A for 0 e B for 1 (0 - 1)
    assign C = ~A & B;

endmodule
