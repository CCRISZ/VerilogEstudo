module full_subtractor (
    input A, B, Cin,
    output S, Cout
);

    // S = A ⊕ B ⊕ Cin
    assign S = A ^ B ^ Cin;

    // Cout = (~A · B) + (~A · Cin) + (B · Cin)
    // Pede emprestado para o próximo bloco se o A for menor que os outros
    assign Cout = (~A & B) | (~A & Cin) | (B & Cin);

endmodule
