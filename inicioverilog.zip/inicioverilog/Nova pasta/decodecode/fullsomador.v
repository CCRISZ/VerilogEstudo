module full_adder (
    input A, B, Cin,
    output S, Cout
);

    // S = A ⊕ B ⊕ Cin
    assign S = A ^ B ^ Cin;

    // Cout = B·Cin + A·Cin + A·B
    assign Cout = (B & Cin) | (A & Cin) | (A & B);

endmodule
