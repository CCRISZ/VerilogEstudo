module decoder_3x8 (
    input A2, A1, A0, EN,
    output reg D7, D6, D5, D4, D3, D2, D1, D0
);

    always @(*) begin
        D7 = 0; D6 = 0; D5 = 0; D4 = 0; D3 = 0; D2 = 0; D1 = 0; D0 = 0;

        if (EN == 1) begin
            case ({A2, A1, A0})
                3'b000: D0 = 1;
                3'b001: D1 = 1;
                3'b010: D2 = 1;
                3'b011: D3 = 1;
                3'b100: D4 = 1;
                3'b101: D5 = 1;
                3'b110: D6 = 1;
                3'b111: D7 = 1;
                default: ; 
            endcase
        end
    end

endmodule
