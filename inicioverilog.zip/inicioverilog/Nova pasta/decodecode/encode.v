module encode (
    input AX, BX, CX, DX,
    output reg a, b, c, d, e, f, g
);

    always @(*) begin
        
        a = 0; b = 0; c = 0; d = 0; e = 0; f = 0; g = 0;

        case ({AX, BX, CX, DX})    
            4'b0000: begin f = 1; a = 1; b = 1; c = 1; d = 1; e = 1; end
            4'b0001: begin b = 1; c = 1; end
            4'b0010: begin d = 1; e = 1; g = 1; b = 1; a = 1; end 
            4'b0011: begin a = 1; b = 1; g = 1; c = 1; d = 1; end
            4'b0100: begin f = 1; b = 1; g = 1; c = 1; end
            4'b0101: begin a = 1; f = 1; g = 1; c = 1; d = 1; end
            4'b0110: begin a = 1; f = 1; g = 1; c = 1; d = 1; e = 1; end
            4'b0111: begin a = 1; b = 1; c = 1; end
            4'b1000: begin a = 1; b = 1; c = 1; d = 1; e = 1; f = 1; g = 1; end
            4'b1001: begin a = 1; b = 1; c = 1; d = 1; f = 1; g = 1; end
            4'b1010: begin f = 1; a = 1; b = 1; g = 1; c = 1; e = 1; end 
            4'b1011: begin f = 1; g = 1; e = 1; d = 1; c = 1; end
            4'b1100: begin a = 1; f = 1; e = 1; d = 1; end
            4'b1101: begin b = 1; g = 1; c = 1; d = 1; e = 1; end
            4'b1110: begin a = 1; f = 1; g = 1; e = 1; d = 1; end
            4'b1111: begin a = 1; f = 1; g = 1; e = 1; end
            default: begin
                a = 1'bx; b = 1'bx; c = 1'bx; d = 1'bx; 
                e = 1'bx; f = 1'bx; g = 1'bx;
            end
        endcase
    end

endmodule
