module alarmee( 
    input wire P, W, M, 
    output wire S, // Agora S é uma saída válida e pode receber um assign
    output wire A 
); 

    assign S = P | W; // Válido: S é uma saída
    assign A = S | M; // Válido: S pode ser lido para calcular A

endmodule
