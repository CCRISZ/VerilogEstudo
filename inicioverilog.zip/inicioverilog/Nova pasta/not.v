module nao_gate (
    input  wire a,
    output wire S
);

    assign S = ~a;

endmodule
