module meu_bloco (
    input wire a,      // Pino de entrada (1 bit)
    input wire b,      // Outro pino de entrada
    output wire saida  // Pino de saída (1 bit)
); // <--- Atenção: tem ponto e vírgula aqui!

    // A lógica do circuito vai aqui dentro

endmodule // <--- Atenção: NÃO tem ponto e vírgula aqui!
