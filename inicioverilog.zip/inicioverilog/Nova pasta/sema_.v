module semaa(input wire A, input wire B, output wire S_A, output wire S_B);

    assign S_A = A & ~B | A & B;
    assign S_B = ~A & B;


endmodule