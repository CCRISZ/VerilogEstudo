`include "not.v"

module meu_circuito (
    input  wire entrada_A,
    input  wire entrada_B,
    output wire S_A,
    output wire S_B
);

    
    wire inversoA;
    nao_gate invA (
        .a(entrada_A),
        .S(inversoA)
    );

    wire inversoB;
    nao_gate invB (
        .a(entrada_B),
        .S(inversoB)
    );

    
    wire saidaA1;
    ANDD and_inst1 (
        .A(entrada_A),
        .B(inversoB),
        .S(saidaA1)
    );
    
    wire saidaA2;
    ANDD and_inst2 (
        .A(entrada_A),
        .B(entrada_B),
        .S(saidaA2)
    );

    OR or_inst1 (
        .A(saidaA1),
        .B(saidaA2),
        .S(S_A)
    );


    ANDD and_inst3 (
        .A(inversoA),
        .B(entrada_B),
        .S(S_B)
    );

endmodule



module ANDD (
    input wire A, 
    input wire B, 
    output wire S
);
    assign S = A & B;
endmodule

module nao_gate (
    input wire a,
    output wire S
);
    assign S = ~a;
endmodule

module OR (
    input wire A, 
    input wire B, 
    output wire S
);
    assign S = A | B;
endmodule

