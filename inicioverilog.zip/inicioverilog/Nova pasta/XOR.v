module XOR (input wire A, input wire B,output wire S);

    assign S = A ^ B;

endmodule